import EventEmitter from "events";

export interface FileSystem extends EventEmitter { }
